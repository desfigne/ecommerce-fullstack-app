export default function CompanyPage() {
  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold">회사 소개</h1>
      <p className="mt-4">브랜드 스토리 및 채용 정보 페이지입니다.</p>
    </div>
  );
}
