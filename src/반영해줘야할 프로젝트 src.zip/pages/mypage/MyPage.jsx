export default function MyPage() {
  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold">마이페이지</h1>
      <p className="mt-4">회원정보, 주문 내역, 찜한 상품 등을 확인할 수 있습니다.</p>
    </div>
  );
}
